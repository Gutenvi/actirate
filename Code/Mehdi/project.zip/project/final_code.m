%% loading files and extracting ECG and PPG signals
r=readtable('0707-1630-A.csv');
vec=table2array(r(2:end,2));

ppg=flip(vec);

[hdr, record] = edfread('16-30-15.EDF');
ecg=flip(record(1,:));

ecg_fs=125;
ppg_fs=100;

time=[1:length(ecg)]./ecg_fs;

%% filtering
% Bandpass filter
[b,a]=butter(5,[1 120]/125/2,'bandpass');
bp_ecg_sig=filtfilt(b,a,ecg);

% removing very low frequency noise that stoping signal to remain on zero line
% using wavelet transform

% Logical array for selecting reconstruction elements
levelForReconstruction = [true, true, true, true, true, true, false, false];
% Perform the decomposition using modwt
wt = modwt(bp_ecg_sig, 'sym4', 7);
% Construct MRA matrix using modwtmra
mra = modwtmra(wt, 'sym4');
% Sum along selected multiresolution signals
filtered_ecg_sig = sum(mra(levelForReconstruction,:),1);



%% plotting signals over time
figure
plot(time,ecg)
hold on
plot(time,filtered_ecg_sig)
xlabel('time')
ylabel('Amplitude')
title 'Raw ECG and Filtered ECG'
legend('Raw ECG','Filtered ECG')

%% Periodogram
[Pxx,Freq] = periodogram(ecg,rectwin(length(ecg)),length(ecg),125);
figure
subplot(121)
   plot(Freq,10*log10(Pxx))
   grid on;
   xlabel('frequency (Hz)'); ylabel('power/frequency (dB/Hz)');
   title 'Periodogram of Raw ECG'

 [Pxx,Freq] = periodogram(filtered_ecg_sig,rectwin(length(filtered_ecg_sig)),length(filtered_ecg_sig),125);
 subplot(122)
   plot(Freq,10*log10(Pxx))
   grid on;
   xlabel('frequency (Hz)'); ylabel('power/frequency (dB/Hz)');
   ylim ([-20,70])
   title 'Periodogram of Filtered ECG'
   
%% FFT of filtered ecg signal
l=length(filtered_ecg_sig);
nfft=2^nextpow2(l);
freq=ecg_fs/2*linspace(0,1,nfft/2+1)
f_xn=abs(fft(filtered_ecg_sig,nfft));
figure
plot(freq , f_xn(1:length(freq)))
title 'FFT of Filtered ECG'

%% Dominant frequency
x = filtered_ecg_sig;
x = x - mean(x);                                            
nfft = 2^nextpow2(length(x)); % next larger power of 2
y = fft(x,nfft); % Fast Fourier Transform
y = abs(y.^2); % raw power spectrum density
y = y(1:1+nfft/2); % half-spectrum
[v,k] = max(y); % find maximum
f_scale = (0:nfft/2)* 125/nfft; % frequency scale
f_dominant = f_scale(k);

mp= (k-1)*125/nfft
figure
plot(f_scale, y)
grid('on')
title(['Dominant Frequency ', num2str(mp), ' Hz'])
xline(mp,'--r','linewidth',3)

